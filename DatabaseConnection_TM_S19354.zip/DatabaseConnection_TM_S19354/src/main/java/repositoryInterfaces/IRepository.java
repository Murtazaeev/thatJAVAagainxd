package repositoryInterfaces;

import DTO.DTOBase;

import java.sql.Connection;


public interface IRepository<TDTO extends DTOBase> {

    void add(TDTO dto);

    void addOrUpdate(TDTO dto);

    void update(TDTO dto);

    void delete(TDTO dto);

    void beginTransaction();

    void commitTransaction();

    void rollbackTransaction();

    int getCount() throws Throwable;

    boolean exists(TDTO dto);

    TDTO findById(int id);

    Connection getConnect();

}
