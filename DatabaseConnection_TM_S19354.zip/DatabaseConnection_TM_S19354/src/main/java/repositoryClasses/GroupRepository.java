package repositoryClasses;

import DTO.GroupDTO;
import repositoryInterfaces.IGroupRepository;

import java.sql.*;
import java.util.*;


public final class GroupRepository extends RepositoryBase<GroupDTO> implements IGroupRepository {

    private String sequenceName = "groups_sequence";
    private String tableName = "GROUPS";

    public GroupRepository(Connection connect) throws SQLException {
        super(connect);
    }

    public void add(GroupDTO groupDTO) {
        try {
            Connection c = getConnect();
            String str = "INSERT INTO " + "GROUPS" + " VALUES( " + sequenceNextValue(sequenceName) + ", ?, ?)";

            PreparedStatement preparedStatement = c.prepareStatement(str);

            preparedStatement.setString(1, groupDTO.getName());
            preparedStatement.setString(2, groupDTO.getDescription());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void update(GroupDTO groupDTO) {
        try {
            Connection c = getConnect();
            String str = "UPDATE " + "GROUPS" + " SET " + "GROUPS_NAME" + " = ?, " + "GROUPS_DESCRIPTION" + " = ? WHERE " + "GROUPS_ID" + " = ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);

            preparedStatement.setString(1, groupDTO.getName());
            preparedStatement.setString(2, groupDTO.getDescription());
            preparedStatement.setInt(3, groupDTO.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void delete(GroupDTO groupDTO) {
        try {
            Connection c = getConnect();
            String str = "DELETE FROM " + "GROUPS" + " WHERE " + "GROUPS_ID" + " = ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);

            preparedStatement.setInt(1, groupDTO.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public GroupDTO findById(int id){
        try {
            Connection c = getConnect();
            String str = "SELECT " + "GROUPS_ID" + ", " + "GROUPS_NAME" + ", " + "GROUPS_DESCRIPTION" + " FROM " + "GROUPS" + " WHERE " + "GROUPS_ID" + "= ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            int x = resultSet.getFetchSize();
            if(x == 1){
                resultSet.first();
                int group_id = resultSet.getInt(1);
                String group_name = resultSet.getString(2);
                String group_description = resultSet.getString(3);
                return new GroupDTO(group_id, group_name, group_description);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<GroupDTO> findByName(String name) {
        try {
            List<GroupDTO> groups = new LinkedList<>();
            Connection c = getConnect();
            String str = "SELECT " + "GROUPS_ID" + ", " + "GROUPS_NAME" + ", " + "GROUPS_DESCRIPTION" + " FROM " + "GROUPS" + " WHERE " + "GROUPS_NAME" + " LIKE ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);
            preparedStatement.setString(1, name);

            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int group_id = resultSet.getInt(1);
                String group_name = resultSet.getString(2);
                String group_description = resultSet.getString(3);
                groups.add(new GroupDTO(group_id, group_name, group_description));
            }
            return groups;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getTableName() {
        return tableName;
    }

}
