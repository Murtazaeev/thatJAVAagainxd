package repositoryClasses;

import DTO.DTOBase;
import repositoryInterfaces.IRepository;

import java.sql.*;


public abstract class RepositoryBase<TDTO extends DTOBase> implements IRepository<TDTO> {

    private Connection connect;

    public RepositoryBase(Connection connect) throws SQLException {
        this.connect = connect;
        connect.setAutoCommit(false);
    }

    private String getCountQuery(){
        String str = "SELECT COUNT(1) FROM ";
        return str + getTableName();
    }

    public abstract String getTableName();
    public Connection getConnect() {
        return connect;
    }
    public void addOrUpdate(TDTO dto) {
        if(exists(dto)) {
            update(dto);
        }
        else {
            add(dto);
        }
    }
    public boolean exists(TDTO dto) {
        if(dto.hasExistingId()){
            TDTO savedEntity = findById(dto.getId());
            return savedEntity != null;
        }
        return false;
    }

    public String sequenceNextValue(String sequenceName){
        String str = "NEXT VALUE FOR ";
        return str + sequenceName;
    }
    public void beginTransaction(){
        try {
            Connection c = getConnect();
            c.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void commitTransaction(){
        try {
            Connection c = getConnect();
            c.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void rollbackTransaction(){
        try {
            Connection c = getConnect();
            c.rollback();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public int getCount() throws Throwable {
        try {
            Connection c = getConnect();
            PreparedStatement preparedStatement = c.prepareStatement(getCountQuery());
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getInt(1);
            }
            else {
                throw new Throwable("result set can not be iterated");
            }
        } catch (SQLException e) {
            throw new Throwable(e);
        }
    }

}
