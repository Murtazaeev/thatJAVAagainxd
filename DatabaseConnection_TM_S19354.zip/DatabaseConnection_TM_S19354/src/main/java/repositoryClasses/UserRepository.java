package repositoryClasses;

import DTO.UserDTO;
import repositoryInterfaces.IUserRepository;

import java.sql.*;
import java.util.*;


public final class UserRepository extends RepositoryBase<UserDTO> implements IUserRepository {

    private String sequenceName = "users_sequence";
    private String tableName = "USERS";

    public UserRepository(Connection connect) throws SQLException {
        super(connect);
    }

    public void add(UserDTO userDTO) {
        try {
            Connection c = getConnect();
            String str = "INSERT INTO " + "USERS" + " VALUES( " + sequenceNextValue(sequenceName) + ", ?, ?)";

            PreparedStatement preparedStatement = c.prepareStatement(str);

            preparedStatement.setString(1, userDTO.getLogin());
            preparedStatement.setString(2, userDTO.getPassword());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void update(UserDTO userDTO) {
        try {
            Connection c = getConnect();
            String str = "UPDATE " + "USERS" + " SET " + "USERS_LOGIN" + " = ?, " + "USERS_PASSWORD" + " = ? WHERE " + "USERS_ID" + " = ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);

            preparedStatement.setString(1, userDTO.getLogin());
            preparedStatement.setString(2, userDTO.getLogin());
            preparedStatement.setInt(3, userDTO.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void delete(UserDTO userDTO) {
        try {
            Connection c = getConnect();
            String str = "DELETE FROM " + "USERS" + " WHERE " + "USERS_ID" + " = ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);

            preparedStatement.setInt(1, userDTO.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public UserDTO findById(int id){
        try {
            Connection c = getConnect();
            String str = "SELECT " + "USERS_ID" + ", " + "USERS_LOGIN" + ", " + "USERS_PASSWORD" + " FROM " + "USERS" + " WHERE " + "USERS_ID" + "= ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            int x = resultSet.getFetchSize();
            if(x == 1){
                resultSet.first();
                int user_id = resultSet.getInt(1);
                String user_login = resultSet.getString(2);
                String user_password = resultSet.getString(3);
                return new UserDTO(user_id, user_login, user_password);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<UserDTO> findByName(String name) {
        try {
            List<UserDTO> users = new LinkedList<>();
            Connection c = getConnect();
            String str = "SELECT " + "USERS_ID" + ", " + "USERS_LOGIN" + ", " + "USERS_PASSWORD" + " FROM " + "USERS" + " WHERE " + "USERS_LOGIN" + " LIKE ?";

            PreparedStatement preparedStatement = c.prepareStatement(str);
            preparedStatement.setString(1, name);

            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int user_id = resultSet.getInt(1);
                String user_login = resultSet.getString(2);
                String user_password = resultSet.getString(3);
                users.add(new UserDTO(user_id, user_login, user_password));
            }
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getTableName() {
        return tableName;
    }
}
