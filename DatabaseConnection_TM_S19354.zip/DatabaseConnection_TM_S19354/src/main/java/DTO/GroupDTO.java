package DTO;

import java.util.*;

public class GroupDTO extends DTOBase{

    private String groups_name;
    private String groups_description;
    private List<UserDTO> users;

    public GroupDTO(int id, String groups_name, String groups_description) {
        super(id);
        this.groups_name = groups_name;
        this.groups_description = groups_description;
    }

    public void addUser(UserDTO user){
        if(users == null)
            users = new LinkedList<UserDTO>();
        users.add(user);
    }
    public void deleteUser(UserDTO user){
        if(users != null)
            users.remove(user);
    }

    public String getName() {
        return groups_name;
    }

    public void setName(String groups_name) {
        this.groups_name = groups_name;
    }

    public String getDescription() {
        return groups_description;
    }

    public List<UserDTO> getUsers() {
        return users;
    }

    public void setUsers(List<UserDTO> users) {
        this.users = users;
    }
}
