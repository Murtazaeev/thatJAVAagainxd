package DTO;

import java.util.*;


public class UserDTO extends DTOBase{

    private String users_login;
    private String users_password;
    private List<GroupDTO> groups;

    public UserDTO(int id, String users_login, String users_password) {
        super(id);
        this.users_login = users_login;
        this.users_password = users_password;
    }

    public void addToGroup(GroupDTO group){
        if(groups == null)
            groups = new LinkedList<GroupDTO>();
        groups.add(group);
    }
    public void deleteFromGroup(GroupDTO group){
        if(groups != null)
            groups.remove(group);
    }

    public String getLogin() {
        return users_login;
    }

    public void setLogin(String users_login) {
        this.users_login = users_login;
    }

    public String getPassword() {
        return users_password;
    }

    public void setPassword(String users_password) {
        this.users_password = users_password;
    }

    public List<GroupDTO> getGroups() {
        return groups;
    }

    public void setGroups(List<GroupDTO> groups) {
        this.groups = groups;
    }

}
