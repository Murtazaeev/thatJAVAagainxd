package DTO;

public class DTOBase {

    private int id;

    public DTOBase(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public boolean hasExistingId(){
        return id != 0;
    }

}
