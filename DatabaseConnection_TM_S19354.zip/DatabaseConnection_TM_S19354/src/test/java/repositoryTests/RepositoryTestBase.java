package repositoryTests;

import DTO.DTOBase;
import org.junit.After;
import org.junit.Before;
import repositoryInterfaces.IRepository;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public abstract class RepositoryTestBase<TDTO extends DTOBase,
                                         TRepository extends IRepository<TDTO>,
                                         TRepositoryImpl extends TRepository> {

    static String uri = "jdbc:sqlserver://localhost:1434";
    static String username = "admin";
    static String password = "12345678";

    private static Connection connection() throws SQLException {
        return DriverManager.getConnection(uri, username, password);
    }

    private TRepository repository;

    public TRepository repository(){
        return repository;
    }

    public RepositoryTestBase(Class<TRepositoryImpl> classType) throws NoSuchMethodException, SQLException,
            IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<TRepositoryImpl> constructor = classType.getConstructor(Connection.class);
        constructor.setAccessible(true);
        repository = constructor.newInstance(connection());
    }

    private void beginTransaction(){
        TRepository repository = repository();
        repository.beginTransaction();
    }
    private void rollbackTransaction(){
        TRepository repository = repository();
        repository.rollbackTransaction();
    }
    private void commitTransaction() {
        TRepository repository = repository();
        repository.commitTransaction();
    }

    @Before
    public void before(){
        beginTransaction();
    }

    @After
    public void after(){
        //commitTransaction();
        rollbackTransaction();
    }


}
