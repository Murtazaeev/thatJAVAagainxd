package repositoryTests;

import DTO.GroupDTO;
import DTO.UserDTO;
import org.junit.Assert;
import org.junit.Test;
import repositoryInterfaces.IUserRepository;
import repositoryClasses.UserRepository;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;


public final class UserRepositoryTest extends RepositoryTestBase<UserDTO, IUserRepository, UserRepository> {

    public UserRepositoryTest() throws NoSuchMethodException, SQLException, IllegalAccessException,
            InvocationTargetException, InstantiationException {
        super(UserRepository.class);
    }

    @Test
    public void add() throws Throwable {
        int current = repository().getCount();
        int expected = current + 1;
        repository().add(new UserDTO(1, "test", "test_password"));
        int actual = repository().getCount();
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void update(){
        String originalLogin = "testStartLogin";
        UserDTO userDTO = new UserDTO(1, originalLogin, "testStartLogin_pass");
        repository().add(userDTO);
        List<UserDTO> originalList = repository().findByName(originalLogin);
        Assert.assertNotNull(originalList);
        Assert.assertEquals(1, originalList.size());
        UserDTO originalUserDTO = originalList.get(0);
        Assert.assertNotNull(originalUserDTO);
        Assert.assertEquals(originalLogin, originalUserDTO.getLogin());
        String modifiedLogin = "testModifiedName";
        originalUserDTO.setLogin(modifiedLogin);
        repository().update(originalUserDTO);
        List<UserDTO> modifiedList = repository().findByName(modifiedLogin);
        Assert.assertNotNull(modifiedList);
        Assert.assertEquals(1, modifiedList.size());
        UserDTO modifiedUserDTO = modifiedList.get(0);
        Assert.assertNotNull(modifiedUserDTO);
        Assert.assertEquals(modifiedLogin, modifiedUserDTO.getLogin());
        Assert.assertEquals(originalUserDTO.getId(), modifiedUserDTO.getId());
    }

}