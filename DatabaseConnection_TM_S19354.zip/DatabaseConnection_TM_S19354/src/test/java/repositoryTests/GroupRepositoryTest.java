package repositoryTests;

import DTO.GroupDTO;
import org.junit.Assert;
import org.junit.Test;
import repositoryClasses.GroupRepository;
import repositoryInterfaces.IGroupRepository;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;


public final class GroupRepositoryTest extends RepositoryTestBase<GroupDTO, IGroupRepository, GroupRepository> {

    public GroupRepositoryTest() throws NoSuchMethodException, SQLException, IllegalAccessException,
            InvocationTargetException, InstantiationException {
        super(GroupRepository.class);
    }

    @Test
    public void add() throws Throwable {
        int current = repository().getCount();
        int expected = current + 1;
        repository().add(new GroupDTO(1, "test", "test_description"));
        int actual = repository().getCount();
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void update(){
        String originalName = "testStartName";
        GroupDTO groupDTO = new GroupDTO(1, originalName, "testStartName_desc");
        repository().add(groupDTO);
        List<GroupDTO> originalList = repository().findByName(originalName);
        Assert.assertNotNull(originalList);
        Assert.assertEquals(1, originalList.size());
        GroupDTO originalGroupDTO = originalList.get(0);
        Assert.assertNotNull(originalGroupDTO);
        Assert.assertEquals(originalName, originalGroupDTO.getName());
        String modifiedName = "testModifiedName";
        originalGroupDTO.setName(modifiedName);
        repository().update(originalGroupDTO);
        List<GroupDTO> modifiedList = repository().findByName(modifiedName);
        Assert.assertNotNull(modifiedList);
        Assert.assertEquals(1, modifiedList.size());
        GroupDTO modifiedGroupDTO = modifiedList.get(0);
        Assert.assertNotNull(modifiedGroupDTO);
        Assert.assertEquals(modifiedName, modifiedGroupDTO.getName());
        Assert.assertEquals(originalGroupDTO.getId(), modifiedGroupDTO.getId());
    }
}
